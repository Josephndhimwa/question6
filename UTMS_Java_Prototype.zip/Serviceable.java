public interface Serviceable {
    void performService();
}
