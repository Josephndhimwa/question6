public interface Schedulable {
    void schedule();
}
