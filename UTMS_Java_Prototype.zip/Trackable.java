public interface Trackable {
    void trackLocation();
}
